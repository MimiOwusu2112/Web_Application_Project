import './accept.css';
import logo from './ug.png'; 

function Accept() {
  return (
    <div className="studentaccept">
      <div className="accept-box">
        <div className="accept">
          <img src={logo} alt="Logo" />
          <h1>Congratulations!!</h1>
        </div>
      </div>
    </div>
  );
}

export default Accept;
