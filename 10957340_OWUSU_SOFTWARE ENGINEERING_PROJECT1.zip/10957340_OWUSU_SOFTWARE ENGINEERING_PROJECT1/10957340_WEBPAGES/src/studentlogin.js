import './studentlogin.css';
import logo from './ug.png'; 
import { Link } from 'react-router-dom';

function StudentLogin() {
  return (
    <div className="studentlogin">
      <div className="login-box">
        <div className="login">
          <img src={logo} alt="Logo" />
          <h1>UNIVERSITY OF GHANA </h1>
          <h1>SCHOOL OF ENGINEERING SCIENCES</h1>
          <label>STUDENT ID</label>
          <input type="text" name="" required />
          <p>
            <label>STUDENT PIN </label>
            <input type="password" name="" required />
          </p>
          <h5>
        <Link to>Login</Link>
      
      </h5> 
            <h5>
              <Link>
              Forgot Password
                </Link>
            </h5>
            <h5>
            <Link to='/' >
              Back to Homepage
            </Link>
              
            </h5>
          
        </div>
      </div>
    </div>
  );
}

export default StudentLogin;
