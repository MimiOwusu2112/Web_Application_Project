import React from 'react';
import { Link } from 'react-router-dom';
import './homepage.css';
import logo from './ug.png'; 

function Homepage() {
  return (
    <div className="homepage">
     <div className="home-box">  
      <div className="home">
        <img src={logo} alt="Logo" className="logo" />
        <h1>UNIVERSITY OF GHANA </h1>
          <h1>WELCOME TO SCHOOL OF ENGINEERING SCIENCES</h1>
          <Link to="/registration">
                  Register
                </Link>
          <p>
          </p>
          <Link to="/login">
                  Login
                  
                </Link>
                <br></br>
                <br></br>
                
                <Link to="/student_profile">
                  Student Profile
                </Link>
        </div>
      </div>
    </div>
  );
}

export default Homepage;
