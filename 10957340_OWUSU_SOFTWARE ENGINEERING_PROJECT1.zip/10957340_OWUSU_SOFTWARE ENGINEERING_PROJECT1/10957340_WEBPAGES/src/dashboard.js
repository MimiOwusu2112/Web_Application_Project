import './dashboard.css';
import logo from './ug.png'; 
import { Link } from 'react-router-dom';

function Dashboard() {
  return (
    <div className="dashboard">
      <div className="dashboard-box">
        <img src={logo} alt="Logo" />
        <h1>UNIVERSITY OF GHANA</h1>
        <h1>WELCOME TO SCHOOL OF ENGINEERING SCIENCES</h1>
        
        <p>
        You may access numerous features and information from this page.
        </p>
        <h5>
        <Link to='/student_profile'>View Profile</Link>
      
      </h5> 
            <h5>
              <Link to='/'>
              Back to Homepage
                </Link>
            </h5>
            <h5>
            <Link to >
              Logout
            </Link>
              
            </h5>
      </div>
    </div>
  );
}

export default Dashboard;
