import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';


import Homepage from './homepage';
import Dashboard from './dashboard';
import StudentLogin from './studentlogin';
import StudentRegistration from './studentregistration'; 
import StudentProfile from './studentprofile';
import Accept from './accept';


function App() {
  return (
    <BrowserRouter>
      
        <Routes>

        <Route path="/" element={<Homepage />} />
          <Route path="/registration" element={<StudentRegistration />} />
          <Route path="/login" element={<StudentLogin />} />
          <Route path="/dashboard" element={<Dashboard/>} />
          <Route path="/student_profile" element={<StudentProfile/>} />
          <Route path="/accept" element={<Accept/>} />
      

        </Routes>
          
      
    </BrowserRouter>
  );
}

ReactDOM.render(<App />, document.getElementById('root'));
